  <!-- footer -->
  <br>
  <footer class="py-5  bg-dark">
      <div class="container">
          <div class="row text-white p-4 text-justify mt-3">
              <div class="col-md-4">
                  <p class="copyright">
                      Copyright &copy;<script>
                          document.write(
                              new Date()
                              .getFullYear()
                          );
                      </script> Energi Termal Solusi <i aria-hidden="true"></i>
                  </p>
              </div>



              <div class="col-md-4 text-white">
                  <div class="cat">
                      <!-- <img src="assets/img/fav.png" width="" height="" /> Hubungi Kami -->
                      <h5>Hubungi Kami</h5>
                  </div>
                  <p>
                      <i class="fa fa-phone"></i> (021) 439-32352
                  </p>
                  <p>
                      <i class="fas fa-map-marker-alt"></i> Jl. H. Murtado Jl.Komp Tugu Permai Blok B3 No.10 Koja, Jakarta Utara
                  </p>
                  <p>
                      <i class="far fa-envelope"></i> energitermal@gmail.com
                  </p>
              </div>


              <div class="col-md-4">
                  <button class="btn btn-outline-success rounded-circle mr-3 mt-3 ml-6"><a target="_blank" href="https://twitter.com/EnergiTermal">
                          <i class="fab fa-twitter"></i></a>
                  </button>

                  <button class="btn btn-outline-success rounded-circle mr-3 mt-3 ml-6"><a target="_blank" href="www.linkedin.com/in/energi-termal-a23112019">
                          <i class="fab fa-facebook"></i></a>
                  </button>

                  <button class="btn btn-outline-success rounded-circle mr-3 mt-3"><a target="_blank" href="https://accounts.google.com/ServiceLogin/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=AddSession">
                          <i class="fas fa-envelope"></i></a>
                  </button>

                  <!-- <button class="btn btn-outline-success rounded-circle mr-3 mt-3"><a target="_blank" href="www.linkedin.com/in/energi-termal-a23112019">
                          <i class="fab fa-linkedin"></i></a>
                  </button> -->

                  <button class="btn btn-outline-success rounded-circle mr-3 mt-3"><a target="_blank" href="https://www.linkedin.com/in/energi-termal-a23112019">
                          <i class="fab fa-linkedin"></i></a>
                  </button>
              </div>
          </div>
      </div>
      <!-- </footer> -->