<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>


<script src="<?php echo base_url(); ?>assets/js/script.js"></script>


<!-- script sosial media -->
<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v5.0"></script>

<script src="assets/js/bootnavbar.js"></script>

<script>
    $(function() {
        $('#main_navbar').bootnavbar();
    })
</script>

</body>

</html>